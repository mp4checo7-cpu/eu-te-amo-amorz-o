import { useEffect, useState } from "react";
import "./App.css";

type Page = "inicio" | "carta" | "momentos" | "surpresa";

const frases = [
  "Algumas pessoas tornam os dias mais especiais simplesmente por existirem. ❤️",
  "Seu sorriso tem um jeito especial de deixar tudo mais leve. 💗",
  "Os pequenos momentos podem se transformar nas melhores lembranças. ✨",
  "Você é uma pessoa que merece todo carinho do mundo. 💕",
  "Espero que essa página consiga arrancar um sorriso seu. 💖",
];

const momentos = [
  {
    emoji: "🌷",
    numero: "01",
    titulo: "O começo",
    texto:
      "Tudo começa com uma pessoa especial e alguns momentos que ficam guardados.",
  },
  {
    emoji: "✨",
    numero: "02",
    titulo: "Os momentos",
    texto:
      "São as pequenas coisas, conversas e risadas que acabam se tornando inesquecíveis.",
  },
  {
    emoji: "💗",
    numero: "03",
    titulo: "O carinho",
    texto:
      "Com o tempo, algumas pessoas acabam conquistando um espaço especial na nossa vida.",
  },
  {
    emoji: "💌",
    numero: "04",
    titulo: "Essa página",
    texto:
      "E tudo isso aqui foi criado especialmente para Ana Júlia.",
  },
];

export default function App() {
  const [entrou, setEntrou] = useState(false);
  const [pagina, setPagina] = useState<Page>("inicio");
  const [cartaAberta, setCartaAberta] = useState(false);
  const [fraseAtual, setFraseAtual] = useState(0);
  const [momentoAtual, setMomentoAtual] = useState(0);
  const [surpresaAberta, setSurpresaAberta] = useState(false);
  const [coracoes, setCoracoes] = useState<number[]>([]);

  useEffect(() => {
    if (coracoes.length === 0) return;

    const timer = setTimeout(() => {
      setCoracoes([]);
    }, 3500);

    return () => clearTimeout(timer);
  }, [coracoes]);

  function navegar(destino: Page) {
    setPagina(destino);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  function criarChuvaDeCoracoes() {
    setCoracoes(
      Array.from(
        { length: 24 },
        (_, index) => Date.now() + index
      )
    );
  }

  function abrirCarta() {
    setCartaAberta(true);
    criarChuvaDeCoracoes();
  }

  function abrirSurpresa() {
    setSurpresaAberta(true);
    criarChuvaDeCoracoes();
  }

  function reiniciarPagina() {
    setCartaAberta(false);
    setSurpresaAberta(false);
    setFraseAtual(0);
    setMomentoAtual(0);
    navegar("inicio");
  }

  if (!entrou) {
    return (
      <div className="entrada">
        <div className="entrada-bg">
          <span>♡</span>
          <span>♥</span>
          <span>♡</span>
          <span>♥</span>
          <span>♡</span>
        </div>

        <div className="entrada-card">
          <div className="entrada-icon">💌</div>

          <div className="mini-label">
            UMA PÁGINA ESPECIAL
          </div>

          <h1>Para Ana Júlia</h1>

          <p>
            Existe uma pequena surpresa esperando por você.
          </p>

          <button
            className="primary-button"
            onClick={() => setEntrou(true)}
          >
            ✨ Entrar
          </button>

          <small>Feito com carinho ❤️</small>
        </div>
      </div>
    );
  }

  return (
    <div className="app">

      <div className="background-hearts" aria-hidden="true">
        {Array.from({ length: 18 }).map((_, index) => (
          <span
            key={index}
            style={{
              left: `${(index * 7) % 100}%`,
              animationDelay: `${index * 0.7}s`,
              animationDuration: `${7 + (index % 4)}s`,
            }}
          >
            {index % 3 === 0 ? "♡" : "♥"}
          </span>
        ))}
      </div>

      <div className="heart-burst" aria-hidden="true">
        {coracoes.map((id, index) => (
          <span
            key={id}
            style={{
              left: `${5 + ((index * 17) % 90)}%`,
              animationDelay: `${index * 0.04}s`,
            }}
          >
            {["❤️", "💗", "💕", "💖", "✨"][index % 5]}
          </span>
        ))}
      </div>

      <div className="content-layer">

        <header className="header">

          <button
            className="logo"
            onClick={() => navegar("inicio")}
          >
            ❤️ Ana Júlia
          </button>

          <nav className="navigation">

            <button
              className={pagina === "inicio" ? "active" : ""}
              onClick={() => navegar("inicio")}
            >
              🏠 Início
            </button>

            <button
              className={pagina === "carta" ? "active" : ""}
              onClick={() => navegar("carta")}
            >
              💌 Carta
            </button>

            <button
              className={pagina === "momentos" ? "active" : ""}
              onClick={() => navegar("momentos")}
            >
              ✨ Momentos
            </button>

            <button
              className={pagina === "surpresa" ? "active" : ""}
              onClick={() => navegar("surpresa")}
            >
              🎁 Surpresa
            </button>

          </nav>

        </header>

        {pagina === "inicio" && (
          <main className="page">

            <section className="hero">

              <div className="hero-heart">
                💖
              </div>

              <div className="label">
                UMA PEQUENA DECLARAÇÃO
              </div>

              <h2>
                Para <strong>Ana Júlia</strong>
              </h2>

              <p>
                Algumas pessoas merecem mais do que uma
                simples mensagem. Por isso, essa página foi
                criada especialmente para você.
              </p>

              <div className="hero-buttons">

                <button
                  className="primary-button"
                  onClick={() => navegar("carta")}
                >
                  💌 Abrir carta
                </button>

                <button
                  className="secondary-button"
                  onClick={() => navegar("momentos")}
                >
                  ✨ Explorar
                </button>

              </div>

            </section>

            <section className="stats">

              <div className="stat">
                <strong>∞</strong>
                <span>Momentos</span>
              </div>

              <div className="stat">
                <strong>❤️</strong>
                <span>Carinho</span>
              </div>

              <div className="stat">
                <strong>✨</strong>
                <span>Sorrisos</span>
              </div>

            </section>

            <section className="quote-card">

              <div className="quote-mark">
                “
              </div>

              <p>
                {frases[fraseAtual]}
              </p>

              <button
                onClick={() =>
                  setFraseAtual(
                    (valor) =>
                      (valor + 1) % frases.length
                  )
                }
              >
                ✨ Outra frase
              </button>

            </section>

          </main>
        )}

        {pagina === "carta" && (
          <main className="page center-page">

            <section className="white-card">

              {!cartaAberta ? (

                <div className="closed-letter">

                  <div
                    className="envelope"
                    onClick={abrirCarta}
                  >
                    💌
                  </div>

                  <div className="pink-label">
                    UMA CARTA
                  </div>

                  <h2>
                    Tem uma mensagem para você
                  </h2>

                  <p>
                    Clique no envelope para descobrir.
                  </p>

                  <button
                    className="primary-button"
                    onClick={abrirCarta}
                  >
                    💌 Abrir carta
                  </button>

                </div>

              ) : (

                <div className="letter-text">

                  <div className="letter-heart">
                    💖
                  </div>

                  <div className="pink-label">
                    PARA ANA JÚLIA
                  </div>

                  <h2>
                    Querida Ana Júlia,
                  </h2>

                  <p>
                    Talvez eu não consiga colocar em palavras
                    exatamente tudo o que gostaria de dizer,
                    mas queria deixar registrado o quanto você
                    é uma pessoa especial.
                  </p>

                  <p>
                    Existem pessoas que chegam de uma forma
                    simples e, aos poucos, acabam tornando
                    momentos comuns muito mais especiais.
                  </p>

                  <p>
                    As conversas, as risadas e até os pequenos
                    detalhes podem acabar se transformando em
                    lembranças importantes.
                  </p>

                  <p>
                    Então, se algum dia você se perguntar o
                    quanto é especial, espero que lembre desta
                    pequena página.
                  </p>

                  <div className="final-message">
                    Você é muito especial. ❤️
                  </div>

                  <div className="signature">
                    Com carinho,
                    <br />
                    alguém que preparou tudo isso para você. 💗
                  </div>

                  <button
                    className="outline-button"
                    onClick={() => setCartaAberta(false)}
                  >
                    ↩ Fechar carta
                  </button>

                </div>

              )}

            </section>

          </main>
        )}

        {pagina === "momentos" && (
          <main className="page">

            <section className="section-title">

              <div className="label">
                PEQUENOS DETALHES
              </div>

              <h2>
                Momentos que <strong>importam</strong>
              </h2>

              <p>
                Porque às vezes são as pequenas coisas que
                tornam tudo especial.
              </p>

            </section>

            <section className="timeline">

              {momentos.map((item, index) => (

                <button
                  className={`timeline-item ${
                    momentoAtual === index
                      ? "selected"
                      : ""
                  }`}
                  key={item.numero}
                  onClick={() => setMomentoAtual(index)}
                >

                  <div className="timeline-number">
                    {item.numero}
                  </div>

                  <div className="timeline-content">

                    <span>
                      {item.emoji}
                    </span>

                    <h3>
                      {item.titulo}
                    </h3>

                    {momentoAtual === index && (
                      <p>
                        {item.texto}
                      </p>
                    )}

                  </div>

                  <div className="timeline-arrow">
                    {momentoAtual === index
                      ? "−"
                      : "+"}
                  </div>

                </button>

              ))}

            </section>

          </main>
        )}

        {pagina === "surpresa" && (
          <main className="page center-page">

            <section className="white-card surprise-card">

              {!surpresaAberta ? (

                <>
                  <div className="gift">
                    🎁
                  </div>

                  <div className="pink-label">
                    ÚLTIMA SURPRESA
                  </div>

                  <h2>
                    Tem algo escondido aqui...
                  </h2>

                  <p>
                    Você chegou até o final.
                    Agora falta descobrir a última surpresa.
                  </p>

                  <button
                    className="primary-button"
                    onClick={abrirSurpresa}
                  >
                    🎁 Descobrir
                  </button>
                </>

              ) : (

                <div className="final-surprise">

                  <div className="big-heart">
                    💖
                  </div>

                  <div className="pink-label">
                    ANA JÚLIA
                  </div>

                  <h2>
                    Você é especial.
                  </h2>

                  <p>
                    Essa página pode ter acabado,
                    mas ainda existe uma última mensagem:
                  </p>

                  <div className="eu-te-amo">
                    EU TE AMO
                    <span>❤️</span>
                  </div>

                  <div className="sparkles">
                    ✨ 💕 ✨ 💕 ✨
                  </div>

                  <button
                    className="outline-button"
                    onClick={reiniciarPagina}
                  >
                    🏠 Voltar ao início
                  </button>

                </div>

              )}

            </section>

          </main>
        )}

        <footer>
          Feito com ❤️ especialmente para Ana Júlia
        </footer>

      </div>
    </div>
  );
}